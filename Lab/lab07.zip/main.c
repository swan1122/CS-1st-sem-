#include "functions.h"

#define SIZE 15

int main(void) {

    // Part A
    float xArray[SIZE]; xArray[0] = 25;
    float yArray[SIZE] = {109.4, 110.1, 112.0, 114.7, 116.0, 
    118.1, 119.5, 121.8, 123.1, 124.9, 127.6, 129.4, 130.6, 131.9, 134.1};

    for (int i = 1; i < SIZE; i++) {
        xArray[i] = xArray[i-1] + 5;
    }
    
    for (int i = 0; i < SIZE; i++) {
        printf("\nPoint %d = (%.1f, %.1f)\n", i+1, xArray[i], yArray[i]);
    }
    
    // Part B
    float Xavg = average(xArray, SIZE);
    printf("\nAverage of x[] = %.2f\nAverage of y[] = %.2f\n", Xavg, average(yArray, SIZE));

    // Part C
    float d = dFunction(xArray, SIZE);
    printf("\nd (of x[]) = %.2f\n", d);

    // Part D
    printf("\na = %.3f\n", aFunction(xArray, yArray, SIZE));

    // Part E
    printf("\nb = %.1f\n", bFunction(xArray, yArray, SIZE));

    // Part F - I
    float deltaY = deltaYfunction(xArray, yArray, SIZE);
    printf("\ndeltaY = %.2f\n", deltaY);

    // Part F - II
    float deltaA = deltaY/sqrt(d);
    float deltaB = deltaY * sqrt(1/SIZE + pow(Xavg, 2)/d);

    printf("\ndeltaA = %.3f\ndeltaB = %.3f\n", deltaA, deltaB);

    return 0;
}