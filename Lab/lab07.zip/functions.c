#include "functions.h"

// Part B
float average(float array[], int size) {
    
    float sum = 0;
    for (int i = 0; i < size; i++) {
        sum += array[i];
    }
    return sum/size;
}

// Part C
float dFunction(float array[], int size){

    float sum = 0;
    for (int i = 0; i < size; i++) {
        sum += pow(array[i] - average(array, size), 2);
    }

    return sum;
}

// Part D
float aFunction(float xArray[], float yArray[], int size) {

    float sum = 0;
    // I'll just make this into a variable since the average for X is the only one which will be used and its value will never change
    float avg = average(xArray, size);

    for (int i = 0; i < size; i++) {
        sum += yArray[i] * (xArray[i] - avg);
    }
    
    return sum/dFunction(xArray, size);
}

// Part E
float bFunction(float xArray[], float yArray[], int size) {
    float a = aFunction(xArray, yArray, size);
    float Yavg = average(yArray, size), Xavg = average(xArray, size);

    float b = Yavg - (a * Xavg);    

    return b;
}

// Part F
float deltaYfunction(float xArray[], float yArray[], int size) {
    float a = aFunction(xArray, yArray, size);
    float b = bFunction(xArray, yArray, size);
    float sum = 0;
    
    for (int i = 0; i < size; i++) {
        sum += pow((yArray[i] - (a * xArray[i] + b)), 2);
    }

    float deltaY = sqrt(sum / (size - 2));
    
    return deltaY;
}