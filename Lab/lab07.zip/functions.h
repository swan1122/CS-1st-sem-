#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float average(float array[], int size);

float dFunction(float array[], int size);

float aFunction(float xArray[], float yArray[], int size);

float bFunction(float xArray[], float yArray[], int size);

float deltaYfunction(float xArray[], float yArray[], int size);

#endif
