#include <stdio.h>
#include <stdlib.h>

#define SIZE 10

void sortArray(int array[]) {

    for (int i = 0; i < SIZE; i++) {
        for (int k = 0; k < SIZE; k++) {
            if (array[k] > array[i]) {
                array[i] = array[i] - array[k];
                array[k] = array[k] + array[i];
                array[i] = array[k] - array[i];
            }
        }   
    }
    
}

int main() {
    int array[SIZE];
    int *pointer_to_array;

    pointer_to_array = array;

    for (int i = 0; i < SIZE; i++) {
        array[i] = rand() % 100;
    }

    // BEFORE sorting
    printf("\nElements in array are:");
    for (int i = 0; i < SIZE; i++) {
        printf("\narray[%d] = %d ", i,  array[i]);
    }

    sortArray(pointer_to_array);

    // AFTER sorting
    printf("\nElements in array are:");
    for (int i = 0; i < SIZE; i++) {
        printf("\narray[%d] = %d ", i,  array[i]);
    }
    
    return 0;
}