#include <stdio.h>
#include <stdlib.h>

#define SIZE 10

int main() {
    int array[SIZE];
    int sum = 0;

    printf("\nEnter 10 elements: ");
    for (int i = 0; i < SIZE; i++) {
        scanf("%d", &array[i]);
    }
    
    printf("\nArray in reverse order: ");
    for (int i = 9; i > -1; i--) {
        sum += array[i];
        printf("\narray[%d] = %d ", i,  array[i]);
    }

    printf("\nSum of all elements of the array = %d\n", sum);

    return 0;
}
