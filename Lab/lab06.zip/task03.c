#include <stdio.h>
#include <stdlib.h>

#define SIZE 10

int main() {
    int array[SIZE];

    for (int i = 0; i < SIZE; i++) {
        array[i] = rand() % 100;
    }

    int max, min = array[0];

    // BEFORE sorting
    printf("\nElements in array are:");
    for (int i = 0; i < SIZE; i++) {
        printf("\narray[%d] = %d ", i,  array[i]);
    }

    // SORTING
    for (int i = 0; i < SIZE; i++) {
        for (int k = 0; k < SIZE; k++) {
            if (array[k] > array[i]) {
                array[i] = array[i] - array[k];
                array[k] = array[k] + array[i];
                array[i] = array[k] - array[i];
            }
        }   
    }
    
    // AFTER sorting
    printf("\n\nElements in sorted array are:");
    for (int i = 0; i < SIZE; i++) {
        printf("\narray[%d] = %d ", i,  array[i]);
    }

    return 0;
}