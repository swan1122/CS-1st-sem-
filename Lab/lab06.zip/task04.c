#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void randomSort(int size) {
    int array[size];
    clock_t timeStart, timeEnd;

    for (int i = 0; i < size; i++) {
        array[i] = rand() % 100;
    }

    int max, min = array[0];
    
    // Get the time BEFORE the sorting
    timeStart = clock();

    // SORTING
    for (int i = 0; i < size; i++) {
        for (int k = 0; k < size; k++) {
            if (array[k] > array[i]) {
                array[i] = array[i] - array[k];
                array[k] = array[k] + array[i];
                array[i] = array[k] - array[i];
            }
        }   
    }

    // Get the time AFTER the sorting
    timeEnd = clock();

    // Print how much time it took for the sorting algorithm to function properly
    printf("\n[%d] elements - [%lf] seconds", size, (double) (timeEnd - timeStart) / CLOCKS_PER_SEC);
}

int main() {
    int amount;
    printf("\nSorting time for an array of:\n");
    for (int i = 1; i < 16; i++) {
        amount = i * 10000;
        randomSort(amount);
    }
    printf("\n");
    
}