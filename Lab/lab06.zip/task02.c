#include <stdio.h>
#include <stdlib.h>

#define SIZE 10

int main() {
    int array[SIZE];

    for (int i = 0; i < SIZE; i++) {
        array[i] = rand() % 91;
    }

    int max, min = array[0];

    for (int i = 9; i > -1; i--) {
        if (array[i] > max) {
            max = array[i];
        }
        if (array[i] < min) {
            min = array[i];
        }
    }

    printf("\nElements in array are:");
    for (int i = 9; i > -1; i--) {
        printf("\narray[%d] = %d ", i,  array[i]);
    }

    printf("\nMaximum element = %d\nMinimum element = %d\n", max, min);

    return 0;
}