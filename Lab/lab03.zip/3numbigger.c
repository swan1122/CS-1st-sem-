#include <stdio.h>

int main() {

    int x, y, z, max;

    printf("Enter values for three different numbers: ");
    scanf("%d %d %d", &x, &y, &z);

    printf("\n1st Number = %d\n2nd Number = %d\n3rd Number = %d", x, y, z);

    // step D
    if (x > y && x > z)
        max = x;
    // step E
    if (y > x && y > z)
        max = y;
    // step F
    if (z > y && z > x)
        max = z;
    printf("\n\nThe %d is the greatest among three.\n", max);

    return 0;
}