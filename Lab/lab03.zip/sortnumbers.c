#include <stdio.h>

int main() {
    int a, b, c, d;
    int array[4] = {a, b, c, d};

    char array_char[4] = {'a', 'b', 'c', 'd'};
    
    for (int i = 0; i < 4; i++) {
        printf("\nInput the value of [%c]\nAnswer: ", array_char[i]);
        scanf("%d", &array[i]);
    }
    
    printf("\n=> BEFORE SWAP:\n=> ");
    for (int i = 0; i < 4; i++) {
        printf("[%c = %d] ", array_char[i], array[i]);
    }

    if (array[3] > array[0]) {
    array[0] = array[0] - array[3];
    array[3] = array[3] + array[0];
    array[0] = array[3] - array[0];
    }

    if (array[2] > array[0]) {
    array[0] = array[0] - array[2];
    array[2] = array[2] + array[0];
    array[0] = array[2] - array[0];
    }

    if (array[2] > array[1]) {
    array[1] = array[1] - array[2];
    array[2] = array[2] + array[1];
    array[1] = array[2] - array[1];
    }

    if (array[2] > array[0]) {
    array[0] = array[0] - array[2];
    array[2] = array[2] + array[0];
    array[0] = array[2] - array[0];
    }

    if (array[3] > array[2]) {
    array[2] = array[2] - array[3];
    array[3] = array[3] + array[2];
    array[2] = array[3] - array[2];
    }

    // Sorry, I thought I should sort them from biggest to smallest, so the order is reversed :^P

    printf("\n\n=> AFTER SWAP:\n=> ");
    for (int i = 0; i < 4; i++) {
        printf("[%c = %d] ", array_char[i], array[i]);
    }

    return 0;
}