#include <stdio.h>
#include <math.h>

int main() {

    float a, b, c, discriminant;

    printf("For a quadratic function on the molds of [ax² + bx + c]\n");
    printf("\nInput the value of [a]\nAnswer: "); scanf("%f", &a);
    printf("\nInput the value of [b]\nAnswer: "); scanf("%f", &b);
    printf("\nInput the value of [c]\nAnswer: "); scanf("%f", &c);

    discriminant = (b*b) - (4*a*c);
    float root1, root2;

    // step c
    if (discriminant > 0) {
        root1 = ((-b + sqrt(discriminant) ) / (2*a));
        root2 = ((-b - sqrt(discriminant) ) / (2*a));

        printf("\nRoots are real.\nRoot1 = %f\nRoot2 = %f\n", root1, root2);
    } else if (!(discriminant - 0)) {
        root1 = root2 = (-b / (2*a));
        printf("\nRoots are real and they're equal.\nRoot1 = %f = Root2\n", root1);
    } else if (discriminant < 0) {
        printf("\nRoots are complex.\nNo real solution.\n");
    }
    


    return 0;
}