#include <stdio.h>

int main() {

    int x, y, big;

    printf("Enter values for two different numbers: ");
    scanf("%d %d", &x, &y);

    printf("\n1st Number = %d, 2nd Number = %d\n", x, y);

    if (x > y)
        big = x;
    else
        big = y;

    printf("\n%d is maximum\n", big);

    return 0;
}