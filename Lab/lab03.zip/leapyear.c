#include <stdio.h>

int main (){
    int year;

    printf("Enter year: ");
    scanf("%d", &year);

    if(!(year % 4) && ((year % 100) || !(year%400))){
        printf("LEAP YEAR - %d\n", year);
    } else {
        printf("COMMON YEAR %d\n", year);
    }

    return 0;
}