#include <stdio.h>

int main() {

    int num1, num2, biggest;
    printf("Input two numbers: ");
    scanf("%d %d", &num1, &num2);
    biggest = num1 - num2;

    switch (num1 > num2)
    {
    case 0:
        biggest = num2;
        break; 
    case 1:
        biggest = num1;
        break;
    }

    printf("\n[RESULT]: %d is maximum.", biggest);

    switch (biggest % 2)
    {
    case 0:
        printf("\n[RESULT]: Maximum is even.");
        break; 
    case 1:
        printf("\n[RESULT]: Maximum is odd.");
        break;
    }


    return 0;
}