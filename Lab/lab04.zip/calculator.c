#include <stdio.h>

int main() {

    char operation;
    float num1, num2;

    printf("\n[CALCULATOR]\nInput your expression as follows: [1st number] [ + - * / ] [2nd number]\nYour expression: ");
    scanf("%f %c %f", &num1, &operation, &num2);

    switch (operation) {
    case '+': // Addition

        printf("[ADDITION] - [RESULT]\n%f + %f = %f\n", num1, num2, (num1+num2));
        break;
    case '-': // Subtraction

        printf("\n[SUBTRACTION] - [RESULT]\n%f - %f = %f\n", num1, num2, (num1-num2));
        break;
    case '*': // Multiplication
    
        printf("\n[MULTIPLICATION] - [RESULT]\n%f × %f = %f\n", num1, num2, (num1*num2));
        break;
    case '/': // Division

        printf("\n[DIVISION] - [RESULT]\n%f ÷ %f = %f\n", num1, num2, (num1/num2));
        break;
    default:
        printf("\t=>[ERROR]\n\t=> Invalid operator!\n");
        break;
    }
    return 0;
}