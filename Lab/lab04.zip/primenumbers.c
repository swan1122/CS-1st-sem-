#include <stdio.h>

int main(){

    int quantity;

    for (int i = 1; i <= quantity; i++)
    {
        for (int ii = 1; ii < i; i++)
        {
            if (ii == 0 || ii == 1 || ii == 2)
            {
                break;
            } // yeah can't do it in so little time
            
            if (!(i % ii)){
                break;
            }

        }
        
    }
    


    return 0;
}