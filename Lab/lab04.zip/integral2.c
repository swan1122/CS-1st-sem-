#include <stdio.h>

    double f1(double x){
        return 1;
    }
    double f2(double x){
        return x;
    }
    double f3(double x){
        return x*x;
    }
    double f(double x){
        return x*x*x*x + x*x*x + x*x + x + 1;
        }

int main() {

    float begin, end;
    float base1, base2, base3;
    int quant1, quant2, quant3;
    quant1 = 10; quant2 = 100; quant3 = 1000;

    float result1, result2, result3 = 0;

    begin = 0; end = 1; // <= THIS VALUES CAN BE EDITED

    base1 = (end - begin)/quant1;
    base2 = (end - begin)/quant2;
    base3 = (end - begin)/quant3;

    // calculations for 10
    for (float i = begin; i < end; i += base1)
    {
        float Mi = i + (base1/2);
        float height = f(Mi);
        float area = base1 * height;
        result1 += area;
        
    }

    // calculations for 100
    for (float i = begin; i < end; i += base2)
    {
        float Mi = i + (base2/2);
        float height = f(Mi);
        float area = base2 * height;
        result2 += area;
        
    }

    // calculations for 1000
    for (float i = begin; i < end; i += base3)
    {
        float Mi = i + (base3/2);
        float height = f(Mi);
        float area = base3 * height;
        result3 += area;
        
    }
    
    printf("Begin = %f, End = %f\n", begin, end);

    printf("\nRESULT FOR F1 = %f", result1);
    printf("\nRESULT FOR F2 = %f", result2);
    printf("\nRESULT FOR F3 = %f", result3);
    printf("\n");


    return 0;
}