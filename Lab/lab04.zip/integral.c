#include <stdio.h>

    double f1(double x){
        return 1;
    }
    double f2(double x){
        return x;
    }
    double f3(double x){
        return x*x;
    }

int main() {

    float begin, end, base;
    int quant;

    float result1, result2, result3 = 0;

    begin = 0; end = 4; quant = 10; // <= THIS VALUES CAN BE EDITED
    base = (end - begin)/quant;

    // calculations for f1
    for (float i = begin; i < end; i += base)
    {
        float Mi = i + (base/2);
        float height = f1(Mi);
        float area = base * height;
        result1 += area;
        
    }

    // calculations for f2
    for (float i = begin; i < end; i += base)
    {
        float Mi = i + (base/2);
        float height = f2(Mi);
        float area = base * height;
        result2 += area;
        
    }

    // calculations for f3
    for (float i = begin; i < end; i += base)
    {
        float Mi = i + (base/2);
        float height = f3(Mi);
        float area = base * height;
        result3 += area;
        
    }
    
    printf("Begin = %f, End = %f, Number of rectangles = %d, Base = %f\n", begin, end, quant, base);

    printf("\nRESULT FOR F1 = %f", result1);
    printf("\nRESULT FOR F2 = %f", result2);
    printf("\nRESULT FOR F3 = %f", result3);
    printf("\n");


    return 0;
}