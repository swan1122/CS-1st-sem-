#include <stdio.h>

int main(){

    // a) Initialize the days variable.
    int totalDays = 1329;
    int days = totalDays;
    // b) Calculate the numbers of years off of the number of days.
    int years = (totalDays - (totalDays % 365))/365;
    int remainingDays = days % 365;
    // c) Calculate the number or weeks off the number of days remaining.
    int weeks = (remainingDays - (remainingDays % 7))/7;
    remainingDays %= 7;
    // d) Calculate the number of days remaining
    days = remainingDays; // Kinda redundant, but allright
    // e) List the number of years, weeks, and days.
    printf("\nTask 1) CONVERSION OF RAW DAYS TO ORGANIZED DATA (years/weeks/days)\n");
    printf("\n[STARTING VALUE]: %d days.\n\nThe number of years, weeks and days are:\nYEARS: [%d]\nWEEKS: [%d]\nDAYS:  [%d]\n", totalDays, years, weeks, days);

    return 0;

}