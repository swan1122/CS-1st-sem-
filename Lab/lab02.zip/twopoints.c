#include <math.h>
#include <stdio.h>

int main() {
    // a) Declaration of variables
    int x1 = 25; int y1 = 15;
    int x2 = 35; int y2 = 10;

    // b) Declaring the variable "distance" and assigning it its value;
    double raw_d = pow((x2 - x1), 2) + pow((y2 - y1), 2);
    
    // c) Using the sqrt() function from the math.h 
    double d = sqrt(raw_d);

    // d) Printing the result
    printf("\nTask 2) DISTANCE BETWEEN TWO POINTS\n");
    printf("\nPOINT I = (25, 15)\nPOINT II = (35, 10)\n");
    printf("\n[RESULT]:\nThe distance between this two points is of [%lf] units.\n", d);

    return 0;
}