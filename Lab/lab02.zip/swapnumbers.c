#include <stdio.h>

int main() {
    // a) Declare two integers x and y and assign them the values 5 and 7, respectively.
    int x = 5;
    int y = 7;
    // b) Print the values of x and y to the screen.
    printf("\nTask 4) SWAP VALUES OF VARIABLES (WITHOUT USING A THIRD ONE)\n");
    printf("\nBEFORE THE SWAPPING\nVariables:\n[X] = [%d]\n[Y] = [%d]\n", x, y);
    // c) Three assignments are required to swap the values of the variables x and y. [...]
    x = x - y;
    y = y + x;
    x = y - x;
    // d) Print the values of the variables x and y after the swap.
    printf("\nAFTER THE SWAPPING\nVariables:\n[X] = [%d]\n[Y] = [%d]\n", x, y);

    return 0;
}