#include <stdio.h>

int main() {

    // a) Declare an integer variable and assign it any value from 100 to 999.
    int number = 461;
    // b) Print the number on the screen.
    printf("\nTask 3) SUM OF THE THREE DIGITS OF A THREE DIGIT NUMBER");
    printf("\n\nFor the number [%d], the digits themselves are:", number);
    // c) Declare the variable to which you will assign the value of the first digit.
    int d3 = number % 10;
    // d) Declare the variable to which you will assign the value of the second digit.
    int d2 = (number % 100 - d3)/10;
    // e) Declare the variable to which you will assign the value of the third digit.
    int d1 = (number - ((number % 100)/10) - (number % 10))/100;
    // f) Print first, second and third digits. 
    printf("\nFirst digit =  [%d]\nSecond digit = [%d]\nThird digit =  [%d]\n", d1, d2, d3);
    // g) Calculate and print their sum.
    int sum = d1 + d2 + d3;
    printf("\n=> [RESULT]: The sum of the three digits (as shown above) is: [%d]\n", sum);
    return 0;
}